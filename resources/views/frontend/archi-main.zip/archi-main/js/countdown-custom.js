jQuery(document).ready(function() {
        $(function () {
            $('#defaultCountdown').countdown({until: new Date(2022, 02, 20, 8)}); // year, month, date, hour
        });
});		

